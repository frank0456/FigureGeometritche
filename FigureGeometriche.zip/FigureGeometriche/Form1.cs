﻿using FigureGeometriche.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FigureGeometriche
{

    public partial class frmMain : Form
    {
        // foglio di quaderno 20 cm x 30 cm
        const int LATO_X = 200;
        const int LATO_Y = 300;

        const int MARGINE_SINISTRO = 100;
        const int MARGINE_DESTRO = 100;
        const int MARGINE_SUPERIORE = 100;
        const int MARGINE_INFERIORE = 100;

      
        const int LATO_X_FORM = (MARGINE_SINISTRO + LATO_X + MARGINE_DESTRO);
        const int LATO_Y_FORM = (MARGINE_SUPERIORE + LATO_Y + MARGINE_INFERIORE);



        public frmMain()
        {
            InitializeComponent();

            // blocco il form alle dimensioni fissate (okkio!! tiene conto anche della banda superiore e laterale)
            this.MinimumSize = new Size(LATO_X_FORM, LATO_Y_FORM);
            this.MaximumSize = new Size(LATO_X_FORM, LATO_Y_FORM);

        }

        private int X(double x)
        {
            int xLogico = 0;
            xLogico = (int)(x) + MARGINE_SINISTRO;
            return xLogico;
        }

        private int Y(double y)
        {
            int yLogico = 0;
            yLogico = (MARGINE_SUPERIORE + LATO_Y - (int)(y));
            return yLogico;
        }

        private void btnCalcola_Click(object sender, EventArgs e)
        {
            int i = 0;
            Graphics dc = this.CreateGraphics();
            Pen BluePen = new Pen(Color.Blue, 1);
            Pen RedPen = new Pen(Color.Red, 1);

            dc.DrawRectangle(BluePen, MARGINE_SINISTRO + 0, MARGINE_SUPERIORE + 0, LATO_X, LATO_Y);

            Punto[] p = new Punto[10];
            Punto[] pt = new Punto[10];

            p[0] = new Punto ( 70, 35);
            p[1] = new Punto (105, 35);
            p[2] = new Punto (120, 65);
            p[3] = new Punto (105, 95);
            p[4] = new Punto (70,  95);
            p[5] = new Punto (55,  65);


            for (i=0; i<6;i++)
            //dc.DrawLine(BluePen, X(p[i].X), Y(p[i].Y), X(p[i+1].X), Y(p[i+1].Y));

            {
                int j = i + 1;
                if (j == 6) j = 0;
                dc.DrawLine(BluePen, X(p[i].X), Y(p[i].Y), X(p[j].X), Y(p[j].Y));
            }



            for (i = 0; i < 6; i++)
            {
                pt[i] = new Punto(0, 0);
                //pt[i] = p[i].Trasla(-50, 50);
                pt[i] = p[i].Scala(2, 3);
            }

            for (i = 0; i < 6; i++)
            
            {
                int j = i + 1;
                if (j == 6) j = 0;
                dc.DrawLine(RedPen, X(pt[i].X), Y(pt[i].Y), X(pt[j].X), Y(pt[j].Y));
            }


            //dc.DrawLine(BluePen, 0, 0, 100, 100);
            //dc.DrawLine(BluePen, 0, 0, 200, 300);




            //// linea diagonale per vedere lo spazio attorno al foglio
            //dc.DrawLine(BluePen, X(0), Y(0), X(LATO_X), Y(LATO_Y));
            //dc.DrawLine(BluePen, X(0), Y(LATO_Y), X(LATO_X), Y(0));

            //dc.DrawLine(BluePen, X(4), Y(12), X(18), Y(20.5));
            //dc.DrawLine(BluePen, X(10), Y(20.5), X(16), Y(10));
            //dc.DrawLine(BluePen, X(16), Y(10), X(4), Y(10));





        }
    }

    
}
